        <!--  Author Name: MR.ANKIT SAINI
                        GigHub Link: https://github.com/Ankitkumargh
                  linkedin id:  https://www.linkedin.com/in/ankit-kumar-68a962248
                        Visit My Website : webbyexample.com -->
                <?php
session_start();
session_destroy();
$url = 'index.php';
header('Location: ' . $url);

?>
           <!--  Author Name: MR.ANKIT SAINI
                        GigHub Link: https://github.com/Ankitkumargh
                  linkedin id:  https://www.linkedin.com/in/ankit-kumar-68a962248
                        Visit My Website : webbyexample.com -->