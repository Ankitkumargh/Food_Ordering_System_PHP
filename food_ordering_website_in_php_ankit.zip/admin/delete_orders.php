          <!--  Author Name: MR.ANKIT SAINI
                        GigHub Link: https://github.com/Ankitkumargh
                  linkedin id:  https://www.linkedin.com/in/ankit-kumar-68a962248
                        Visit My Website : webbyexample.com -->
                <?php
include("../connection/connect.php");
error_reporting(0);
session_start();

mysqli_query($db,"DELETE FROM users_orders WHERE o_id = '".$_GET['order_del']."'");
header("location:all_orders.php");  

?>
   <!--  Author Name: MR.ANKIT SAINI
                        GigHub Link: https://github.com/Ankitkumargh
                  linkedin id:  https://www.linkedin.com/in/ankit-kumar-68a962248
                        Visit My Website : webbyexample.com -->