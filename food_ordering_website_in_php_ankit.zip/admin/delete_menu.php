<?php
include("../connection/connect.php");
error_reporting(0);
session_start();

mysqli_query($db,"DELETE FROM dishes WHERE d_id = '".$_GET['menu_del']."'");
header("location:all_menu.php");  

?>
<!--  Author Name: MR.ANKIT SAINI
                        GigHub Link: https://github.com/Ankitkumargh
                  linkedin id:  https://www.linkedin.com/in/ankit-kumar-68a962248
                        Visit My Website : webbyexample.com -->