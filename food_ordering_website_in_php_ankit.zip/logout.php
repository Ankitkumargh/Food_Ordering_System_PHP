<!--  Author Name: MR.ANKIT SAINI
                        GigHub Link: https://github.com/Ankitkumargh
            
                        Visit My Website : webbyexample.com -->
<?php
session_start(); 
session_destroy(); 
$url = 'login.php';
header('Location: ' . $url); 

?>
<!--  Author Name: MR.ANKIT SAINI
                        GigHub Link: https://github.com/Ankitkumargh
            
                        Visit My Website : webbyexample.com -->