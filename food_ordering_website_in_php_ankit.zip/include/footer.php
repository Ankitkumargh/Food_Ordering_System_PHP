      <footer class="footer">
          <div class="container">


              <div class="bottom-footer">
                  <div class="row">
                    
                      <div class="col-xs-12 col-sm-3 payment-options color-gray">
                        <h5>Main Features</h5>
                      <div>
									
									<p>Get food delivery to your doorstep from thousands of amazing local and national restaurants.and it's developed in a Raw PHP project. </p>
									<p> 
										<li> HTML5, CSS3 </li>
										<li> Bootstrap 3.3.7, jQuery (Ajax) </li>
										<li> MySQL 5.0.1 </li>
										<li> PHP 7.4.3 </li>
									</p>
								</div>
                          <h5>Payment Options</h5>
                          <ul>
                              <li>
                                  <a href="#"> <img src="images/paypal.png" alt="Paypal"> </a>
                              </li>
                              <li>
                                  <a href="#"> <img src="images/mastercard.png" alt="Mastercard"> </a>
                              </li>
                              <li>
                                  <a href="#"> <img src="images/maestro.png" alt="Maestro"> </a>
                              </li>
                              <li>
                                  <a href="#"> <img src="images/stripe.png" alt="Stripe"> </a>
                              </li>
                              <li>
                                  <a href="#"> <img src="images/bitcoin.png" alt="Bitcoin"> </a>
                              </li>
                          </ul>
                      </div>
                      <div class="col-xs-12 col-sm-4 address color-gray">
                      <h5>Address</h5>
                          
                      

                          <ul class="contact-info">
										<li><span class="contact-info-label">Address:</span>Light City Pilani, Rajasthan INDIA</li><br>
										<li><span class="contact-info-label">Phone:</span>Toll Free <a href="tel:">(+91) 73398837856</a></li><br>
										<li><span class="contact-info-label">Email:</span> <a href="ankit@example.com">ankitksaini1807@gmail.com</a></li><br>
										<li><span class="contact-info-label">Working Days/Hours:</span>Mon - Sun / 9:00AM - 8:00PM</li><br>
									</ul>
                      </div>
                      <div class="col-xs-12 col-sm-5 additional-info color-gray">
                          <h5>Addition informations</h5>

                          <p class="footer-copyright mt-1">All Rights Reserved &copy; <?= date('Y') ?> | Developed By 
							<a href="https://www.linkedin.com/in/ankit-kumar-68a962248" target="_blank"> MR.ANKIT KUMAR </a>
						</p>
                          <!-- <p>Join thousands of other restaurants who benefit from having partnered with us.</p> -->
                          <div class="social-icons">

						    
							<a href="https://github.com/Ankitkumargh" target="_blank" style="margin: 0px 10px;">
								<img src="admin/images/mrankit.png" class="rounded-circle" style="width:50px; height: 50px;">
							</a>				
							<a href="https://www.webbyexample.com/home" target="_blank" style="margin: 0px 10px;">
								<img src="admin/images/google.png" class="rounded-circle" style="width:50px; height: 50px;">
							</a><a href="#" target="_blank" style="margin: 0px 10px;">
								<img src="admin/images/facebook.png" class="rounded-circle" style="width:50px; height: 50px;">
							</a>
                            <a href="#" target="_blank" style="margin: 0px 10px;">
								<img src="admin/images/twitter.png" class="rounded-circle" style="width:50px; height: 50px;">
							</a>
                            <a href="https://www.youtube.com/channel/UCsEGI5-r-wN6-VfEX0f_RVw" target="_blank" style="margin: 0px 10px;">
								<img src="admin/images/youtube.png" class="rounded-circle" style="width:50px; height: 50px;">
							</a>
                            
						</div>
                      </div>
                  </div>
              </div>

          </div>
      </footer>


   